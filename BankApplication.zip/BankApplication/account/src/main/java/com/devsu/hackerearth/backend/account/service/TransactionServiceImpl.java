package com.devsu.hackerearth.backend.account.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;

    public TransactionServiceImpl(TransactionRepository transactionRepository, AccountRepository accountRepository) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
    }

    @Override
    public List<TransactionDto> getAll() {
        return transactionRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(Long id) {
        Optional<Transaction> transactionOpt = transactionRepository.findById(id);
        return transactionOpt.map(this::toDto).orElse(null);
    }

    @Override
    public TransactionDto create(TransactionDto transactionDto) {
        Optional<Account> accOpt = accountRepository.findById(transactionDto.getAccountId());
        if (!accOpt.isPresent())
            throw new RuntimeException("cuenta no encontrada");

        Account account = accOpt.get();

        Optional<Transaction> lastTxOpt = transactionRepository.findTopByAccountIdOrderByDateDesc(account.getId());

        double lastBalance;
        if (lastTxOpt.isPresent()) {
            lastBalance = lastTxOpt.get().getBalance();
        } else {
            lastBalance = account.getInitialAmount();
        }

        double nuevoSaldo = lastBalance + transactionDto.getAmount();

        if (nuevoSaldo < 0) {
            throw new RuntimeException("Saldo no disponible");
        }

        // account.setInitialAmount(nuevoSaldo);
        // accountRepository.save(account);

        Transaction transaction = toEntity(transactionDto);
        transaction.setId(null);
        transaction.setBalance(nuevoSaldo);
        Transaction saved = transactionRepository.save(transaction);
        return toDto(saved);
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {
        Date startOfDay = truncateToStartOfDay(dateTransactionStart);
        Date endOfDay = addDaysAndTruncateToStartOfDay(dateTransactionEnd, 1);

        List<Account> accounts = accountRepository.findByClientId(clientId);
        if (accounts.isEmpty()) {
            System.out.println("No se encontraron cuentas para el cliente: " + clientId);
            return List.of();
        }

        System.out.println("Cuentas encontradas para cliente " + clientId + ": " + accounts.size());
        accounts.forEach(acc -> System.out.println("Cuenta id: " + acc.getId() + ", clientId: " + acc.getClientId()));

        List<Long> accountIds = accounts.stream().map(Account::getId).collect(Collectors.toList());
        List<Transaction> transactions = transactionRepository.findByAccountIdInAndDateBetween(accountIds, startOfDay,
                endOfDay);

        System.out
                .println("Transacciones encontradas para cuentas del cliente " + clientId + ": " + transactions.size());
        transactions.forEach(tx -> System.out.println(
                "Transacción id: " + tx.getId() + ", cuenta: " + tx.getAccountId() + ", fecha: " + tx.getDate()));

        if (transactions.isEmpty()) {
            System.out.println("No se encontraron transacciones para las cuentas del cliente: " + clientId + " entre "
                    + startOfDay + " y " + endOfDay);
        }

        return transactions.stream()
                .map(tx -> toBankStatementDto(tx, accounts))
                .collect(Collectors.toList());
    }

    private Date truncateToStartOfDay(Date date) {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.setTime(date);
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0);
        cal.set(java.util.Calendar.MINUTE, 0);
        cal.set(java.util.Calendar.SECOND, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    private Date addDaysAndTruncateToStartOfDay(Date date, int days) {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.setTime(date);
        cal.add(java.util.Calendar.DATE, days);
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0);
        cal.set(java.util.Calendar.MINUTE, 0);
        cal.set(java.util.Calendar.SECOND, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        Optional<Transaction> lastTx = transactionRepository.findTopByAccountIdOrderByDateDesc(accountId);
        return lastTx.map(this::toDto).orElse(null);
    }

    private TransactionDto toDto(Transaction transaction) {
        return new TransactionDto(
                transaction.getId(),
                transaction.getDate(),
                transaction.getType(),
                transaction.getAmount(),
                transaction.getBalance(),
                transaction.getAccountId());
    }

    private Transaction toEntity(TransactionDto dto) {
        Transaction transaction = new Transaction();
        transaction.setId(dto.getId());
        transaction.setDate(dto.getDate());
        transaction.setType(dto.getType());
        transaction.setAmount(dto.getAmount());
        transaction.setAccountId(dto.getAccountId());
        return transaction;
    }

    private BankStatementDto toBankStatementDto(Transaction transaction, List<Account> accounts) {
        Account account = accounts.stream()
                .filter(acc -> acc.getId().equals(transaction.getAccountId()))
                .findFirst().orElse(null);

        return new BankStatementDto(
                transaction.getDate(),
                account != null ? account.getClientId().toString() : "",
                account != null ? account.getNumber() : "",
                account != null ? account.getType() : "",
                account != null ? account.getInitialAmount() : 0.0,
                account != null && account.getIsActive() != null ? account.getIsActive() : false,
                transaction.getType(),
                transaction.getAmount(),
                transaction.getBalance());
    }

}
