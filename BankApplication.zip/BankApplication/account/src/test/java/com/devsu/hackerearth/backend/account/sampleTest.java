package com.devsu.hackerearth.backend.account;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.devsu.hackerearth.backend.account.controller.AccountController;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;
import com.devsu.hackerearth.backend.account.service.AccountService;
import com.devsu.hackerearth.backend.account.service.TransactionService;
import com.devsu.hackerearth.backend.account.service.TransactionServiceImpl;

@SpringBootTest
public class sampleTest {

	private AccountService accountService = mock(AccountService.class);
	private AccountController accountController = new AccountController(accountService);

	@Test
	void createAccountTest() {
		// Arrange
		AccountDto newAccount = new AccountDto(1L, "number", "savings", 0.0, true, 1L);
		AccountDto createdAccount = new AccountDto(1L, "number", "savings", 0.0, true, 1L);
		when(accountService.create(newAccount)).thenReturn(createdAccount);

		// Act
		ResponseEntity<AccountDto> response = accountController.create(newAccount);

		// Assert
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertEquals(createdAccount, response.getBody());
	}

	@Test
	void testClientModel() {
		Account account = new Account();
		account.setId(1L);
		account.setNumber("123456");
		account.setType("savings");
		account.setInitialAmount(1000.0);
		account.setIsActive(true);
		account.setClientId(1L);

		assertEquals(1L, account.getId());
		assertEquals("123456", account.getNumber());
		assertEquals("savings", account.getType());
		assertEquals(1000.0, account.getInitialAmount());
		assertTrue(account.getIsActive());
		assertEquals(1L, account.getClientId());
	}

	@Test
	void registrarTransaccion_exitosa() {
		AccountRepository accountRepository = mock(AccountRepository.class);
		TransactionRepository transactionRepository = mock(TransactionRepository.class);
		TransactionService transactionService = new TransactionServiceImpl(transactionRepository, accountRepository);

		Account account = new Account();
		account.setId(1L);
		account.setInitialAmount(1000.0);
		when(accountRepository.findById(1L)).thenReturn(Optional.of(account));

		TransactionDto dto = new TransactionDto();
		dto.setAccountId(1L);
		dto.setAmount(-200.0);

		Transaction saved = new Transaction();
		saved.setId(1L);
		saved.setAccountId(1L);
		saved.setAmount(-200.0);

		when(transactionRepository.save(any(Transaction.class))).thenReturn(saved);

		TransactionDto result = transactionService.create(dto);

		assertNotNull(result);
		assertEquals(-200.0, result.getAmount());
		verify(accountRepository).findById(1L);
		verify(transactionRepository).save(any(Transaction.class));
		
	}

	@Test
	void registrarTransaccion_saldoInsuficiente(){
		AccountRepository accountRepository = mock(AccountRepository.class);
		TransactionRepository transactionRepository = mock(TransactionRepository.class);
		TransactionService transactionService = new TransactionServiceImpl(transactionRepository, accountRepository);

		Account account = new Account();
		account.setId(1L);
		account.setInitialAmount(100.0);
		when(accountRepository.findById(1L)).thenReturn(Optional.of(account));

		TransactionDto dto = new TransactionDto();
		dto.setAccountId(1L);
		dto.setAmount(-200.0);

		Exception ex = assertThrows(RuntimeException.class, () -> {
			transactionService.create(dto);
		});
		assertTrue(ex.getMessage().contains("Saldo no disponible"));
	}

	@Test
	void reporteEstadoCuenta_cliente() {
		AccountRepository accountRepository = mock(AccountRepository.class);
		TransactionRepository transactionRepository = mock(TransactionRepository.class);
		TransactionService transactionService = new TransactionServiceImpl(transactionRepository, accountRepository);

		Long clientId = 1L;
		Date fechaInicio = new Date();
		Date FechaFin =  new Date();
		
		Account acc1 = new Account();
		acc1.setId(1L);
		acc1.setClientId(clientId);
		acc1.setInitialAmount(500.0);
		Account acc2 = new Account();
		acc2.setId(2L);
		acc2.setClientId(clientId);
		acc2.setInitialAmount(800.0);

		when(accountRepository.findByClientId(clientId)).thenReturn(Arrays.asList(acc1, acc2));

		Transaction tx1 = new Transaction();
		tx1.setId(1L);
		tx1.setAccountId(1L);
		tx1.setAmount(-100.0);
		tx1.setBalance(400.0);
		tx1.setDate(fechaInicio);

		Transaction tx2 = new Transaction();
		tx2.setId(2L);
		tx2.setAccountId(2L);
		tx2.setAmount(200.0);
		tx2.setBalance(1000.0);
		tx2.setDate(FechaFin);

		when(transactionRepository.findByAccountIdInAndDateBetween(anyList(), any(Date.class), any(Date.class))).thenReturn(Arrays.asList(tx1, tx2));

		List<BankStatementDto> reporte = transactionService.getAllByAccountClientIdAndDateBetween(clientId, fechaInicio, FechaFin);

		assertNotNull(reporte);
		assertEquals(2, reporte.size());
	}
}

