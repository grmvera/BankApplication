package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	// GET

	@Override
	public List<ClientDto> getAll() {
		return clientRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
	}

	// POST

	@Override
	public ClientDto getById(Long id) {
		Optional<Client> clientOpt = clientRepository.findById(id);
		return clientOpt.map(this::toDto).orElse(null);
	}

	//PUT

	@Override
	public ClientDto create(ClientDto clientDto) {
		Client client = toEntity(clientDto);
		client.setId(null);
		Client saved = clientRepository.save(client);
		return toDto(saved);
	}

	//UPDATE

	@Override
	public ClientDto update(Long id, ClientDto clientDto) {
		Optional<Client> existing = clientRepository.findById(id);
		if(!existing.isPresent()) return null;
		Client client = toEntity(clientDto);
		client.setId(id);
		Client updated = clientRepository.save(client);
		return toDto(updated);
	}

	//PATCH

	@Override
    public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
        Optional<Client> clientOpt = clientRepository.findById(id);
		if (clientOpt.isPresent()){
			Client client = clientOpt.get();
			client.setIsActive(partialClientDto.getIsActive());
			Client updated = clientRepository.save(client);
			return toDto(updated);
		}
		return null;
    }

	//DELETE

	@Override
	public void deleteById(Long id) {
		clientRepository.deleteById(id);
	}


	//ENTITY A DTO / DTO A ENTITY

	private ClientDto toDto(Client client){
		return new ClientDto(
			client.getId(),
			client.getDni(),
			client.getName(),
			client.getPassword(),
			client.getGender(),
			client.getAge(),
			client.getAddress(),
			client.getPhone(),
			Boolean.TRUE.equals(client.getIsActive())	
		);
	}


	private Client toEntity(ClientDto dto){
		Client client = new Client();
		client.setId(dto.getId());
		client.setDni(dto.getDni());
		client.setName(dto.getName());
		client.setPassword(dto.getPassword());
		client.setGender(dto.getGender());
		client.setAge(dto.getAge());
		client.setAddress(dto.getAddress());
		client.setPhone(dto.getPhone());
		client.setIsActive(dto.getIsActive());
		return client;
	}
}
