package com.devsu.hackerearth.backend.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;

import com.devsu.hackerearth.backend.client.controller.ClientController;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.service.ClientService;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class sampleTest {

    private ClientService clientService = mock(ClientService.class);
    private ClientController clientController = new ClientController(clientService);

    @Test
    void createClientTest() {
        // Arrange
        ClientDto newClient = new ClientDto(1L, "Dni", "Name", "Password", "Gender", 1, "Address", "9999999999", true);
        ClientDto createdClient = new ClientDto(1L, "Dni", "Name", "Password", "Gender", 1, "Address", "9999999999",
                true);
        when(clientService.create(newClient)).thenReturn(createdClient);

        // Act
        ResponseEntity<ClientDto> response = clientController.create(newClient);

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(createdClient, response.getBody());
    }

    @Test
    void testClientModel() {
        Client client = new Client();
        client.setId(1L);
        client.setName("Juan Perez");
        client.setDni("1234567890");
        client.setGender("M");
        client.setAddress("Calle A");
        client.setPhone("09999999999");
        client.setPassword("pass123");
        client.setIsActive(true);

        assertEquals(1L, client.getId());
        assertEquals("Juan Perez", client.getName());
        assertEquals("1234567890", client.getDni());
        assertEquals("M", client.getGender());
        assertEquals("Calle A", client.getAddress());
        assertEquals("09999999999", client.getPhone());
        assertEquals("pass123", client.getPassword());
        assertTrue(client.getIsActive());
    }

    // F6

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void integrationCreateClient() throws Exception {
        ClientDto clientDto = new ClientDto (
            null,
            "9876543210",
            "Pedro Gomez",
            "clave1234",
            "M",
            28,
            "Calle B",
            "0987654321",
            true
        );

        mockMvc.perform(post("/api/clients")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(clientDto)))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.dni").value("9876543210"))
                .andExpect(jsonPath("$.name").value("Pedro Gomez"))
                .andExpect(jsonPath("$.isActive").value(true));
    }
}
